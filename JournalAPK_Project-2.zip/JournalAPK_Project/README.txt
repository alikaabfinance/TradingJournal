Trading Journal Android project

This is a native Android app project for a multi-challenge trading journal.
To build with the provided GitHub Actions workflow, upload this ZIP to the root of your GitHub repository using the exact filename JournalAPK_Project.zip.
Then run Actions > Build Android APK > Run workflow.
The APK will be available under the completed workflow run's Artifacts section.
